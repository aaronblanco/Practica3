package com.example.practica3

data class Product (
    val id: Long,
    val name: String,
    val price: Double
)
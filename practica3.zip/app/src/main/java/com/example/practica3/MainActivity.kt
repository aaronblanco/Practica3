package com.example.practica3

import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.practica3.ui.theme.Practica3Theme
import android.os.Bundle
import android.util.Log
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class MainActivity : ComponentActivity() {
    private lateinit var productAdapter: ProductAdapter
    private lateinit var recyclerView: RecyclerView
    private val apiService = ApiClient.retrofit.create(ApiService::class.java)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
      //  enableEdgeToEdge()
       // setContent {
       //     Practica3Theme {
       //         Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
       //             Greeting(
       //                 name = "Android",
       //                 modifier = Modifier.padding(innerPadding)
       //             )
        //        }
         //   }
     //   }
        setContentView(R.layout.activity_main)
        // Sample product list
        val sampleProducts = listOf(
            Product(1, "Product A", 12.0),
            Product(2, "Product B", 15.5),
            Product(3, "Product C", 7.99)
        )

        // Set up RecyclerView
        recyclerView = findViewById(R.id.recyclerViewProducts)
        recyclerView.layoutManager = LinearLayoutManager(this)
        productAdapter = ProductAdapter(sampleProducts)
        recyclerView.adapter = productAdapter

        // Example API call
        apiService.getAllProducts().enqueue(object : Callback<List<Product>> {
            override fun onResponse(call: Call<List<Product>>, response: Response<List<Product>>) {
                if (response.isSuccessful) {
                    val data = response.body()
                    // Handle the response data, which is a List<Product>
                    data?.let { productList ->
                        // Process productList here
                        productAdapter = ProductAdapter(productList)
                        recyclerView.adapter = productAdapter
                    }
                }else {
                    Log.e("API_ERROR", "Error code: ${response.code()}")
                }
            }
            override fun onFailure(call: Call<List<Product>>, t: Throwable) {
                // Handle error
                Log.e("API_ERROR", "Failure: ${t.message}")
            }
        })
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Practica3Theme {
        Greeting("Android")
    }
}
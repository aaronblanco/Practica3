package com.example.practica3

data class ResponseModel(
    val id: Int,
    val name: String,
    val price: Double
)
